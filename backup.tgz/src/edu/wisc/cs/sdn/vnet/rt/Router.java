package edu.wisc.cs.sdn.vnet.rt;

import net.floodlightcontroller.packet.MACAddress;
import edu.wisc.cs.sdn.vnet.Device;
import edu.wisc.cs.sdn.vnet.DumpFile;
import edu.wisc.cs.sdn.vnet.Iface;
import net.floodlightcontroller.packet.IPv4;
import net.floodlightcontroller.packet.Ethernet;
import net.floodlightcontroller.packet.UDP;
import net.floodlightcontroller.packet.RIPv2;
import net.floodlightcontroller.packet.RIPv2Entry;
import net.floodlightcontroller.packet.ARP;

import java.util.*;

/**
 * @author Aaron Gember-Jacobson and Anubhavnidhi Abhashkumar
 */
public class Router extends Device {
    /** Routing table for the router */
    protected RouteTable routeTable;

    /** ARP cache for the router */
    protected ArpCache arpCache;

    private final boolean dbg = false;
    private RipProtocolHandler ripHandler;

    private static final byte[] BCAST_MAC = new byte[] { (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF };
    private static final String MCAST_RIP_IP = "224.0.0.9";
    private static final int REQ_RIP = 1;
    private static final int RESP_RIP = 2;
    private static final int UNSOLICITED_RIP = 3;

    /**
     * Creates a router for a specific host.
     * @param host hostname for the router
     */
    public Router(String host, DumpFile logfile) {
        super(host, logfile);
        this.routeTable = new RouteTable();
        this.arpCache = new ArpCache();
        this.ripHandler = new RipProtocolHandler();
    }

    /**
     * @return routing table for the router
     */
    public RouteTable getRouteTable() { 
        return this.routeTable; 
    }

    public void init() {
        System.out.println("Starting RIP protocol...");
        final RipProtocolHandler protocolManager = new RipProtocolHandler();
        protocolManager.startRIP(); 
    }

    /**
     * Load a new routing table from a file.
     * @param staticRoutesFile the name of the file containing the routing table
     */
    public void loadRouteTable(String staticRoutesFile) {
        if (!routeTable.load(staticRoutesFile, this)) {
            System.err.println("Error setting up routing table from file " + staticRoutesFile);
            System.exit(1);
        }

        System.out.println("Loaded static route table");
        System.out.println("-------------------------------------------------");
        System.out.print(this.routeTable.toString());
        System.out.println("-------------------------------------------------");
    }

    /**
     * Load a new ARP cache from a file.
     * @param staticArpFile the name of the file containing the ARP cache
     */
    public void loadArpCache(String staticArpFile) {
        if (!arpCache.load(staticArpFile)) {
            System.err.println("Error setting up ARP cache from file " + staticArpFile);
            System.exit(1);
        }

        System.out.println("Loaded static ARP cache");
        System.out.println("----------------------------------");
        System.out.print(this.arpCache.toString());
        System.out.println("----------------------------------");
    }

    /**
     * Handle an Ethernet packet received on a specific interface.
     * @param inboundFrame the Ethernet packet that was received
     * @param ingressPort the interface on which the packet was received
     */
    public void handlePacket(Ethernet inboundFrame, Iface ingressPort) {
        System.out.println("EtherType: " + inboundFrame.getEtherType());
        System.out.println("Dest MAC: " + inboundFrame.getDestinationMAC());
        if (inboundFrame == null || ingressPort == null) {
            return;
        }

        System.out.println("*** ROUTER RECEIVED A PACKET ON " + ingressPort.getName() + " ***");

        switch (inboundFrame.getEtherType()) {
            case Ethernet.TYPE_IPv4:
                System.out.println("-> Dispatching to IPv4 handler");
                this.routeIpv4Datagram(inboundFrame, ingressPort);
                break;

            case Ethernet.TYPE_ARP:
                System.out.println("-> Dispatching to ARP handler");
                this.processArpMessage(inboundFrame, ingressPort);
                break;

            default:
                System.out.println("-> Dropping unknown packet type: " + inboundFrame.getEtherType());
                break;
        }
    }

    public void handleMissingArp(int targetIpGw, Ethernet inboundFrame, Iface ingressPort, Iface egressPort) {
        ARP arpQuery = new ARP();
        arpQuery.setHardwareType(ARP.HW_TYPE_ETHERNET);
        arpQuery.setProtocolType(Ethernet.TYPE_IPv4);
        arpQuery.setHardwareAddressLength((byte) Ethernet.DATALAYER_ADDRESS_LENGTH);
        arpQuery.setProtocolAddressLength((byte) 4);
        arpQuery.setOpCode(ARP.OP_REQUEST);
        
        // Sender is THIS router
        arpQuery.setSenderHardwareAddress(egressPort.getMacAddress().toBytes());
        arpQuery.setSenderProtocolAddress(egressPort.getIpAddress());
        
        // Target is the nextHop IP (Target MAC is unknown/zeros)
        arpQuery.setTargetHardwareAddress(new byte[6]); 
        arpQuery.setTargetProtocolAddress(targetIpGw);

        // Wrap in Ethernet Frame
        Ethernet ethernetWrapper = new Ethernet();
        ethernetWrapper.setEtherType(Ethernet.TYPE_ARP);
        ethernetWrapper.setSourceMACAddress(egressPort.getMacAddress().toBytes());
        ethernetWrapper.setDestinationMACAddress(BCAST_MAC); 
        ethernetWrapper.setPayload(arpQuery);

        // Broadcast it
        this.sendPacket(ethernetWrapper, egressPort);
    }

    private void processArpMessage(Ethernet inboundFrame, Iface ingressPort) {
        if (!(inboundFrame.getPayload() instanceof ARP)) {
            return; 
        }

        ARP arpData = (ARP) inboundFrame.getPayload();
int senderIp = IPv4.toIPv4Address(arpData.getSenderProtocolAddress());
    MACAddress senderMac = new MACAddress(arpData.getSenderHardwareAddress());

this.arpCache.insert(senderMac, senderIp);

        if (arpData.getOpCode() != ARP.OP_REQUEST) {
            return;
        }

        int reqTargetIp = IPv4.toIPv4Address(arpData.getTargetProtocolAddress());
        
        if (reqTargetIp == ingressPort.getIpAddress()) {
            ARP arpResponse = new ARP();
            arpResponse.setHardwareType(ARP.HW_TYPE_ETHERNET);
            arpResponse.setProtocolType(Ethernet.TYPE_IPv4);
            arpResponse.setHardwareAddressLength((byte) Ethernet.DATALAYER_ADDRESS_LENGTH);
            arpResponse.setProtocolAddressLength((byte) 4);
            arpResponse.setOpCode(ARP.OP_REPLY);
            
            arpResponse.setSenderHardwareAddress(ingressPort.getMacAddress().toBytes());
            arpResponse.setSenderProtocolAddress(ingressPort.getIpAddress());
            
            arpResponse.setTargetHardwareAddress(arpData.getSenderHardwareAddress());
            arpResponse.setTargetProtocolAddress(arpData.getSenderProtocolAddress());

            Ethernet replyEthFrame = new Ethernet();
            replyEthFrame.setEtherType(Ethernet.TYPE_ARP);
            replyEthFrame.setSourceMACAddress(ingressPort.getMacAddress().toBytes());
            replyEthFrame.setDestinationMACAddress(inboundFrame.getSourceMACAddress());
            replyEthFrame.setPayload(arpResponse);

            this.sendPacket(replyEthFrame, ingressPort);
        }
    }

    private void forwardIpPacket(Ethernet inboundFrame, Iface ingressPort) {
        IPv4 ipv4Payload = (IPv4) inboundFrame.getPayload();
        RouteEntry forwardingEntry = Router.this.routeTable.lookup(ipv4Payload.getDestinationAddress());

        if (forwardingEntry == null) {

//System.out.println(" No route found in routeTable!"); 
System.out.println("🚨 DROP: No route found for IP: " + IPv4.fromIPv4Address(ipv4Payload.getDestinationAddress()));  

          dispatchIcmp(3, 0, inboundFrame, ingressPort); // Net Unreachable
            return;
        }

        Iface egressPort = forwardingEntry.getInterface();
        if (egressPort == ingressPort) return;

        int nextHopIp = (forwardingEntry.getGatewayAddress() == 0) ? ipv4Payload.getDestinationAddress() : forwardingEntry.getGatewayAddress();
        ArpEntry resolvedMacEntry = Router.this.arpCache.lookup(nextHopIp);

        if (resolvedMacEntry == null) {
            
System.out.println("DROP: ARP Miss! Sending ARP Request instead.");
Router.this.handleMissingArp(nextHopIp, inboundFrame, ingressPort, egressPort);
            return;
        }

        inboundFrame.setSourceMACAddress(egressPort.getMacAddress().toBytes());
        inboundFrame.setDestinationMACAddress(resolvedMacEntry.getMac().toBytes());
        Router.this.sendPacket(inboundFrame, egressPort);
System.out.println("✅ SUCCESS: Packet forwarded out " + egressPort.getName());    

}

    private void dispatchIcmp(int type, int code, Ethernet inboundFrame, Iface ingressPort) {
        // ICMP generation logic goes here
    }

    private void routeIpv4Datagram(Ethernet inboundFrame, Iface ingressPort) {
        if (inboundFrame.getEtherType() != Ethernet.TYPE_IPv4) {
            return;
        }

        IPv4 ipv4Payload = (IPv4)inboundFrame.getPayload();
        short oldChksum = ipv4Payload.getChecksum();
        ipv4Payload.resetChecksum();
        byte[] rawBytes = ipv4Payload.serialize();
        ipv4Payload.deserialize(rawBytes, 0, rawBytes.length);
        if (oldChksum != ipv4Payload.getChecksum()) 
        {
        System.out.println("DROP: Bad Checksum!"); 
        return;
        }
        
        ipv4Payload.setTtl((byte) (ipv4Payload.getTtl() - 1));
        if (ipv4Payload.getTtl() == 0) {
            System.out.println("ttl 0");
            // dispatchIcmp(11, 0, inboundFrame, ingressPort);
            return;
        }

        if (ipv4Payload.getDestinationAddress() == IPv4.toIPv4Address(MCAST_RIP_IP)) {
            System.out.println("📡 RIP MULTICAST RECEIVED");
            ripHandler.handleRIP(inboundFrame, ingressPort);
            return;
        }

        ipv4Payload.resetChecksum();
        // rawBytes = ipv4Payload.serialize();
        // ipv4Payload.deserialize(rawBytes, 0, rawBytes.length);

        int destIp = ipv4Payload.getDestinationAddress();

        System.out.println("=== IPv4 PACKET DEBUG ===");
        System.out.println("Dest IP: " + IPv4.fromIPv4Address(destIp));
        System.out.println("Ingress Port: " + ingressPort.getName());

        boolean isForRouter = false;

        // Check all interfaces
        for (Iface port : Router.this.interfaces.values()) {
            String ifaceIpStr = IPv4.fromIPv4Address(port.getIpAddress());
            System.out.println("Checking interface " + port.getName() + 
                            " with IP " + ifaceIpStr);

            if (destIp == port.getIpAddress()) {
                System.out.println("✅ MATCH: Packet is for THIS router interface!");
                isForRouter = true;

                byte protocolType = ipv4Payload.getProtocol();
                System.out.println("Protocol: " + protocolType);

                if (protocolType == IPv4.PROTOCOL_UDP) {
                    UDP udpDatagram = (UDP) ipv4Payload.getPayload();
                    System.out.println("UDP Dest Port: " + udpDatagram.getDestinationPort());

                    if (udpDatagram.getDestinationPort() == UDP.RIP_PORT) {
                        System.out.println("📡 RIP PACKET RECEIVED (unicast)");
                        ripHandler.handleRIP(inboundFrame, ingressPort);
                        return;
                    }
                }

                System.out.println("⚠️ Packet is for router but not handled (dropping or ICMP)");
                return;
            }
        }

        // Check RIP multicast separately
        if (destIp == IPv4.toIPv4Address(MCAST_RIP_IP)) {
            System.out.println("📡 RIP MULTICAST PACKET RECEIVED (224.0.0.9)");
            ripHandler.handleRIP(inboundFrame, ingressPort);
            return;
        }

        // Not for router → forward
        System.out.println("➡️ NOT for router, forwarding...");
        forwardIpPacket(inboundFrame, ingressPort);
        //forwardIpPacket(inboundFrame, ingressPort);
    }

    // ==============================================================================
    // RIP Protocol Inner Class
    // ==============================================================================

    private class RipProtocolHandler {

        private Map<Integer, RipEntry> ripRouteRegistry = new HashMap<>();
        private static final int INF_METRIC = 16;
        private boolean logRipStatus = true;

        public void startRIP() {
            for (Iface port : Router.this.interfaces.values()) {
                int subnetMask = port.getSubnetMask();
                int netAddress = subnetMask & port.getIpAddress();
                
                ripRouteRegistry.put(netAddress, new RipEntry(netAddress, subnetMask, 0, 0, -1));
                routeTable.insert(netAddress, 0, subnetMask, port);
                
                sendRipUpdate(REQ_RIP, null, port);
            }

            TimerTask periodicBroadcast = new TimerTask() {
                public void run() {
                    if (logRipStatus) System.out.println("Broadcasting periodic RIP response");
                    for (Iface port : interfaces.values()) {
                        sendRipUpdate(UNSOLICITED_RIP, null, port);
                    }
                }
            };

            TimerTask staleRouteCleaner = new TimerTask() {
                public void run() {
                    long currentTime = System.currentTimeMillis();
                    Iterator<Map.Entry<Integer, RipEntry>> iter = ripRouteRegistry.entrySet().iterator();
                    while (iter.hasNext()) {
                        RipEntry record = iter.next().getValue();
                        if (record.lastUpdated != -1 && (currentTime - record.lastUpdated) >= 30000) {
                            if (logRipStatus) System.out.println("Route timed out: " + IPv4.fromIPv4Address(record.networkAddr));
                            routeTable.remove(record.networkAddr, record.networkMask);
                            iter.remove();
                        }
                    }
                }
            };

            Timer taskScheduler = new Timer(true);
            taskScheduler.schedule(periodicBroadcast, 0, 10000);
            taskScheduler.schedule(staleRouteCleaner, 0, 1000);
        }

        public void handleRIP(Ethernet inboundFrame, Iface ingressPort) {
            IPv4 ip = (IPv4)inboundFrame.getPayload();
            UDP udp = (UDP)ip.getPayload();
            RIPv2 rip = (RIPv2)udp.getPayload();

            // short oldChksum = udp.getChecksum();
            // udp.resetChecksum();
            // byte[] rawBytes = udp.serialize();
            // udp.deserialize(rawBytes, 0, rawBytes.length);
            // if (oldChksum != ipv4Payload.getChecksum()) {
            //     System.out.println("DROP: Bad Checksum!"); 
            //     return;
            // }

            byte ripCommand = rip.getCommand();

            switch (ripCommand) {
                case RIPv2.COMMAND_REQUEST:
                    //debug
                    System.out.println("Request");
                    sendRipUpdate(REQ_RIP, inboundFrame, ingressPort);
                    break;

                case RIPv2.COMMAND_RESPONSE:
                    //debug
                    System.out.println("Repsonse");
                    // IPv4 ipv4Payload = (IPv4) inboundFrame.getPayload();
                    // UDP udpDatagram = (UDP) ipv4Payload.getPayload();
                    // RIPv2 ripMessage = (RIPv2) udpDatagram.getPayload();

                    for (RIPv2Entry ripUpdate : rip.getEntries()) {
                        int network = ripUpdate.getAddress() & ripUpdate.getSubnetMask();
                        int calculatedMetric = Math.min(ripUpdate.getMetric() + 1, INF_METRIC);

                        RouteEntry routeEntry = Router.this.routeTable.lookup(network);

                        if (routeEntry == null) {
                            Router.this.routeTable.insert(
                                ripUpdate.getAddress(),
                                ip.getSourceAddress(),
                                ripUpdate.getSubnetMask(),
                                ingressPort
                            );
                        } else {
                            Router.this.routeTable.update(
                                ripUpdate.getAddress(),
                                ripUpdate.getSubnetMask(),
                                ip.getSourceAddress(),
                                ingressPort
                            );
                        }
                    }
                    break;

                default:
				    break;
                }
                for (Iface iface : Router.this.getInterfaces().values()) {
                    sendRipUpdate(RESP_RIP, inboundFrame, ingressPort);
                }
        }

        public void handleRipMessage(byte ripCommand, Ethernet inboundFrame, Iface ingressPort) {
            switch (ripCommand) {
                case RIPv2.COMMAND_REQUEST:
                    sendRipUpdate(RESP_RIP, inboundFrame, ingressPort);
                    break;

                case RIPv2.COMMAND_RESPONSE:
                    IPv4 ipv4Payload = (IPv4) inboundFrame.getPayload();
                    UDP udpDatagram = (UDP) ipv4Payload.getPayload();
                    RIPv2 ripMessage = (RIPv2) udpDatagram.getPayload();

                    for (RIPv2Entry ripUpdate : ripMessage.getEntries()) {
                        int destNetwork = ripUpdate.getAddress() & ripUpdate.getSubnetMask();
                        int calculatedMetric = Math.min(ripUpdate.getMetric() + 1, INF_METRIC);
                        int neighborIp = ipv4Payload.getSourceAddress();

                        synchronized (this.ripRouteRegistry) {
                            if (ripRouteRegistry.containsKey(destNetwork)) {
                                RipEntry currentRecord = ripRouteRegistry.get(destNetwork);
                                currentRecord.lastUpdated = System.currentTimeMillis();

                                if (calculatedMetric < currentRecord.metricCount || currentRecord.hopGateway == neighborIp) {
                                    currentRecord.metricCount = calculatedMetric;
                                    currentRecord.hopGateway = neighborIp;
                                    if (calculatedMetric < INF_METRIC) {
                                        Router.this.routeTable.update(ripUpdate.getAddress(), ripUpdate.getSubnetMask(), neighborIp, ingressPort);
                                    } else {
                                        Router.this.routeTable.remove(ripUpdate.getAddress(), ripUpdate.getSubnetMask());
                                    }
                                }
                            } else if (calculatedMetric < INF_METRIC) {
                                ripRouteRegistry.put(destNetwork, new RipEntry(ripUpdate.getAddress(), ripUpdate.getSubnetMask(), neighborIp, calculatedMetric, System.currentTimeMillis()));
                                Router.this.routeTable.insert(ripUpdate.getAddress(), neighborIp, ripUpdate.getSubnetMask(), ingressPort);
                            }
                        }
                    }
                    break;
            }
        }

        private void sendRipUpdate(int mode, Ethernet requestingFrame, Iface egressPort) {
            Ethernet ethernetWrapper = new Ethernet();
            IPv4 ipHeader = new IPv4();
            UDP udpHeader = new UDP();
            RIPv2 ripMessage = new RIPv2();

            ethernetWrapper.setSourceMACAddress(egressPort.getMacAddress().toBytes());
            ethernetWrapper.setEtherType(Ethernet.TYPE_IPv4);
            ipHeader.setTtl((byte) 64);
            ipHeader.setProtocol(IPv4.PROTOCOL_UDP);
            ipHeader.setSourceAddress(egressPort.getIpAddress());
            udpHeader.setSourcePort(UDP.RIP_PORT);
            udpHeader.setDestinationPort(UDP.RIP_PORT);

            switch (mode) {
                case UNSOLICITED_RIP:
                case REQ_RIP:
                    ripMessage.setCommand(mode == REQ_RIP ? RIPv2.COMMAND_REQUEST : RIPv2.COMMAND_RESPONSE);
                    ethernetWrapper.setDestinationMACAddress(BCAST_MAC);
                    ipHeader.setDestinationAddress(IPv4.toIPv4Address(MCAST_RIP_IP));
                    break;

                case RESP_RIP:
                    IPv4 triggerIp = (IPv4) requestingFrame.getPayload();
                    ripMessage.setCommand(RIPv2.COMMAND_RESPONSE);
                    ethernetWrapper.setDestinationMACAddress(requestingFrame.getSourceMACAddress());
                    ipHeader.setDestinationAddress(triggerIp.getSourceAddress());
                    break;
            }

            List<RIPv2Entry> updateList = new ArrayList<>();
            synchronized (this.ripRouteRegistry) {
                for (RipEntry record : ripRouteRegistry.values()) {
                    updateList.add(new RIPv2Entry(record.networkAddr, record.networkMask, record.metricCount));
                }
            }

            ethernetWrapper.setPayload(ipHeader);
            ipHeader.setPayload(udpHeader);
            udpHeader.setPayload(ripMessage);
            ripMessage.setEntries(updateList);

            Router.this.sendPacket(ethernetWrapper, egressPort);
        }

        private class RipEntry {
            public int networkAddr;
            public int networkMask;
            public int hopGateway;
            public int metricCount;
            public long lastUpdated;

            public RipEntry(int networkAddr, int networkMask, int hopGateway, int metricCount, long lastUpdated) {
                this.networkAddr = networkAddr;
                this.networkMask = networkMask;
                this.hopGateway = hopGateway;
                this.metricCount = metricCount;
                this.lastUpdated = lastUpdated;
            }
        }
    }
}
